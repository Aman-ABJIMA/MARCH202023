let name = prompt("Enter Your Name:");
let nameElement = document.getElementById('name');
nameElement.innerHTML = name;
let scores=0,scr=0;
var count = 5;

function chances(i) 
{

  
    var countDisplay = document.getElementById("count");
    if(count!=0)
    {
       count--;
       countDisplay.innerHTML = count;
       process(i);
     if(count==0)
     {

       if(scores>scr)
       {
           countDisplay.innerHTML = "You WIN!!!"

       }
    
       else if (scores==scr)
       {
       countDisplay.innerHTML = "Tie!!!"
       }
       else
       {
           countDisplay.innerHTML = "You LOSE!!!"
       }
       setTimeout(() => {
           let time = document.location.reload();
       alert("Let's Play Again !!!") }, 1000); 
     }
  }
}


function process(i)
{    
 let rock = document.getElementById('rock');
 let paper = document.getElementById('paper');
 let scissors = document.getElementById('scissors');


switch(i)
{
   case 1:
   rock.style.border = "dotted";
   paper.style.border = "dotted";
   paper.style.borderColor = "rgb(240,240,240)";
   scissors.style.border = "dotted";
   scissors.style.borderColor = "rgb(240,240,240)";
   break;
   
   case 2:
    paper.style.border = "dotted";
    rock.style.border = "dotted";
    rock.style.borderColor = "rgb(240,240,240)"
    scissors.style.border = "dotted";
    scissors.style.borderColor = "rgb(240,240,240)"
    break;
  
    case 3:
       scissors.style.border = "dotted";
       rock.style.border = "dotted";
       rock.style.borderColor ="rgb(240,240,240)"; 
       paper.style.border = "dotted";
       paper.style.borderColor ="rgb(240,240,240)"; 
}




let r = document.getElementById('r');
let p = document.getElementById('p');
let s = document.getElementById('s');
let j = Math.floor(Math.random() * 3);
switch(j)
{
   case 0:
   r.style.border = "dotted";
   p.style.borderColor ="rgb(240,240,240)";
   s.style.borderColor = "rgb(240,240,240)";
   break;
  
   case 1:
   p.style.border = "dotted";
   r.style.borderColor ="rgb(240,240,240)";
   s.style.borderColor ="rgb(240,240,240)";
   break;
  
   case 2:
   s.style.border = "dotted";
   r.style.borderColor ="rgb(240,240,240)";
   p.style.borderColor ="rgb(240,240,240)";
  
}
var scrElement = document.getElementById('scr');
var scoresElement = document.getElementById('scores');
if(i==j+1)
{
  //tie
}
else if(i==1 && j==2 || i==3 && j==1 || i==2 && j==0)
{
   scores++;
   scoresElement.style.color ="Green"
   scrElement.style.color ="Red"
   scoresElement.innerHTML = scores;


}
else
{
   scr++;
   scrElement.style.color ="Green"
   scoresElement.style.color ="Red"
   scrElement.innerHTML = scr;
}

}
